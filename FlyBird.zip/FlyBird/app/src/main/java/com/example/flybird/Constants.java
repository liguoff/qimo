package com.example.flybird;

public class Constants {
    public static float SCREEN_WIDTH;
    public static float SCREEN_HEIGHT;

    public Constants() {
    }
}
